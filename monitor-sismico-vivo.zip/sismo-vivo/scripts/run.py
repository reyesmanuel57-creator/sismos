"""Orquestador: corre el motor adaptativo, publica estado y avisa por WhatsApp
si alguna zona sube a nivel ELEVADO. Ejecutado por GitHub Actions cada 6h."""
import os, sys, json, requests
sys.path.insert(0, os.path.dirname(__file__))
from motor_adaptativo import correr

ESTADO_SITE = os.path.join(os.path.dirname(__file__), "..", "site", "estado.json")

def wa(texto):
    ph, key = os.environ.get("WHATSAPP_PHONE"), os.environ.get("WHATSAPP_APIKEY")
    if not ph or not key:
        print("WhatsApp no configurado; omito."); return
    r = requests.get("https://api.callmebot.com/whatsapp.php",
                     params={"phone": ph, "text": texto, "apikey": key}, timeout=30)
    print("WhatsApp:", r.status_code)

if __name__ == "__main__":
    estado = correr(ESTADO_SITE if os.path.exists(ESTADO_SITE) else "estado_aprendizaje.json")
    json.dump(estado, open(ESTADO_SITE, "w"), ensure_ascii=False, indent=2)
    p = estado["parametros_aprendidos"]
    print(f"OK: {estado['n_eventos_escaneados']} sismos, b={p['b']:.2f}, "
          f"último {estado['ultimo_sismo'][:16]}")
    # avisar solo si hay zona ELEVADO (evita spam): mensaje solo cuando importa
    elevadas = [z for z in estado["zonas"] if z["nivel"] == "ELEVADO"]
    if elevadas:
        msg = "🔴 *ALERTA DE ACTIVIDAD ELEVADA — CHILE*\n\n"
        for z in elevadas:
            msg += (f"*{z['zona'].split('(')[0].strip()}*: prob. M≥6 esta semana "
                    f"{z['prob_M6_7d']*100:.0f}% ({z['n_ult7d']} sismos últimos 7d)\n")
        msg += "\n⚠️ _Probabilidad, no certeza. No indica día/hora/lugar. Oficial: SENAPRED._"
        wa(msg)
    else:
        print("Sin zonas en nivel ELEVADO; no se envía WhatsApp (evita falsas alarmas).")
